import os
import webbrowser
from time import *
import time
import random
import datetime
from PIL import Image
from PIL import ImageTk
import csv
import pandas as pd
import PIL
  
from tkinter import messagebox 
count=0
j=0
history =[]
os.chdir(r"C:\\Users\\lenovo\\Desktop\\take break")
from tkinter import *
L=['https://www.youtube.com/watch?v=wfYVF1L8T1Y','https://www.youtube.com/watch?v=qxaiRb1HeRw']
r = Tk()
image = PIL.Image.open('taking.gif')
C = Canvas(r, bg="blue", height=250, width=300)
filename = PIL.ImageTk.PhotoImage(image)
background_label = Label(r, image = filename)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
C.grid()
entry1 = Entry(r,width=50,borderwidth=5)
#p = entry1.create_text(*textSet, text=p[3]),
#font=("Helvetica",16)
#pa=entry1.create_rectangle(entry1.box)
entry1.grid(row = 0,column = 0,columnspan = 2)
title1 = Label(r,text='Enter the url to add to playlist')
def start_music():
    webbrowser.open('https://www.youtube.com/')
    import time
    count=0
    for i in L :
         webbrowser.open(i)
         j=i
         count=count+1
         add_hist(j)
         time.sleep(3)
         if count > len(L):
          break
                  
   
def stop_music():
        os.system("taskkill /in chrome.exe /f")
        L.clear()
        browserExe = "chrome.exe"
        os.system("taskkill /f /im "+browserExe)
        r.destroy()

            
def show_playlist():
    global playlist
    root2 = Tk()
    root2.title(' Current Playlist')
    y=0
    n = 1
    for i in range(0,len(L)):   
        playlist1 = Label(root2, text= str(n)+': '+L[i])
        playlist1.grid(row = y, column = 0)
        y += 1   
        n += 1
    root2.mainloop()
    
    
def shuffle_music():
    import random
    m=0
    if(len(L) >0) : 
      random.shuffle(L)
      show_playlist()
    
        
     
        
def add_hist(j):
  string=strftime('%H:%M')
  d = str(string)
  with open('jayesh.csv', 'a') as newFile:
     newFileWriter = csv.writer(newFile)
     newFileWriter.writerow([j, d])
    
    
def history_list():
  hist = pd.read_csv("jayesh.csv")
  ht=hist.dropna()
  gh=ht.tail(5)
  top=Tk()
  title2 = Label(top,text=gh).grid(row=1,column=0)
    
  

def add_playlist():
    try:
      L.append(entry1.get())
    except :
      messagebox.showwarning("warning","please add the link first")     
        
    
   


r.geometry('720x450')
url_entry = Entry(r,width = 35,borderwidth =2)
startbutton = Button(r,text='Start',padx = 20, pady = 5,width = 5,height = 2,command=start_music)
exitbutton = Button(r,text='Exit',padx = 20, pady = 5,width = 5,height = 2,command=stop_music)
playlistbutton = Button(r, text='Playlist',height=2,width = 5,padx = 20, pady = 5,command=show_playlist)
shufflebutton = Button(r,text='Shuffle',padx = 20, pady = 5,width = 5,height = 2,command=shuffle_music)
historybutton = Button(r, text='History', padx = 20, pady = 5,width = 5,height = 2,command=history_list)
addbutton = Button(r, text='Add', padx = 20, pady = 5,width = 5,height = 2,command = add_playlist)



addbutton.grid(row=0,column = 2)

playlistbutton.grid(row = 0,column = 3)

startbutton.grid(row = 3,column = 1, rowspan = 3)

shufflebutton.grid(row = 3,column = 2, rowspan = 3)

historybutton.grid(row = 3,column =3,rowspan = 3 )

exitbutton.grid(row =3 ,column = 4,rowspan = 3)

r.mainloop()


